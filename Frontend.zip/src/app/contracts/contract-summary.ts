export class ContractSummary {
    valid?:Number;
    renewal?:Number;
    annulled?:Number;
}
